require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const OpenAI = require('openai');
const path = require('path');

const app = express();
const isProd = process.env.NODE_ENV === 'production';
const port = Number(process.env.PORT || 3000);
const required = ['DATABASE_URL', 'SESSION_SECRET'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}
if (process.env.SESSION_SECRET.length < 32) {
  console.error('SESSION_SECRET must be at least 32 characters long.');
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProd ? { rejectUnauthorized: false } : undefined
});
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'nur_ai_sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd,
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL DEFAULT 'NUR AI пайдаланушысы',
      role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS chat_messages (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK (role IN ('user','assistant')),
      content TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS chat_messages_user_id_id_idx ON chat_messages(user_id, id);
  `);
  const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (email && password) {
    if (password.length < 12) {
      console.warn('ADMIN_PASSWORD should be at least 12 characters; admin bootstrap skipped.');
    } else {
      const existing = await pool.query('SELECT id FROM users WHERE email=$1', [email]);
      if (existing.rowCount === 0) {
        const hash = await bcrypt.hash(password, 12);
        await pool.query(
          "INSERT INTO users(email,password_hash,display_name,role) VALUES($1,$2,$3,'admin')",
          [email, hash, 'NUR AI иесі']
        );
        console.log(`Initial admin account created for ${email}`);
      } else {
        // Existing accounts are never silently promoted or have passwords overwritten.
        console.log('ADMIN_EMAIL already exists; leaving its role/password unchanged.');
      }
    }
  } else {
    console.warn('ADMIN_EMAIL/ADMIN_PASSWORD not set. Register a normal account; admin can be promoted manually in DB if needed.');
  }
}

function safeUser(row) {
  return { id: row.id, email: row.email, displayName: row.display_name, role: row.role };
}
async function currentUser(req) {
  if (!req.session.userId) return null;
  const result = await pool.query('SELECT id,email,display_name,role FROM users WHERE id=$1', [req.session.userId]);
  return result.rows[0] || null;
}
async function requireAuth(req, res, next) {
  try {
    const user = await currentUser(req);
    if (!user) return res.status(401).json({ error: 'Алдымен жүйеге кір.' });
    req.user = user;
    next();
  } catch (e) { next(e); }
}
async function requireAdmin(req, res, next) {
  try {
    const user = await currentUser(req);
    if (!user) return res.status(401).json({ error: 'Алдымен жүйеге кір.' });
    if (user.role !== 'admin') return res.status(403).json({ error: 'Бұл бөлім тек әкімшіге арналған.' });
    req.user = user;
    next();
  } catch (e) { next(e); }
}

app.get('/api/health', (req, res) => res.json({ ok: true, aiConfigured: Boolean(openai) }));
app.get('/api/me', async (req, res, next) => {
  try { const user = await currentUser(req); res.json({ user: user ? safeUser(user) : null }); }
  catch (e) { next(e); }
});

app.post('/api/register', authLimiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const displayName = String(req.body.displayName || '').trim().slice(0, 60) || 'NUR AI пайдаланушысы';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
      return res.status(400).json({ error: 'Электрондық пошта форматын тексер.' });
    }
    if (password.length < 10 || password.length > 128) {
      return res.status(400).json({ error: 'Құпиясөз 10–128 таңба болуы керек.' });
    }
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(email,password_hash,display_name,role) VALUES($1,$2,$3,'user') RETURNING id,email,display_name,role",
      [email, hash, displayName]
    );
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = result.rows[0].id;
      req.session.save(err2 => err2 ? next(err2) : res.status(201).json({ user: safeUser(result.rows[0]) }));
    });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Бұл пошта бұрын тіркелген.' });
    next(e);
  }
});

app.post('/api/login', authLimiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const result = await pool.query('SELECT id,email,password_hash,display_name,role FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Пошта немесе құпиясөз қате.' });
    }
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.save(err2 => err2 ? next(err2) : res.json({ user: safeUser(user) }));
    });
  } catch (e) { next(e); }
});

app.post('/api/logout', (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie('nur_ai_sid', { httpOnly: true, secure: isProd, sameSite: 'lax' });
    res.json({ ok: true });
  });
});

app.get('/api/history', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      'SELECT id,role,content,created_at FROM chat_messages WHERE user_id=$1 ORDER BY id DESC LIMIT 100',
      [req.user.id]
    );
    res.json({ messages: result.rows.reverse() });
  } catch (e) { next(e); }
});

app.delete('/api/history', requireAuth, async (req, res, next) => {
  try {
    await pool.query('DELETE FROM chat_messages WHERE user_id=$1', [req.user.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.post('/api/chat', requireAuth, aiLimiter, async (req, res, next) => {
  try {
    const message = String(req.body.message || '').trim();
    if (!message || message.length > 6000) return res.status(400).json({ error: 'Хабарлама 1–6000 таңба аралығында болуы керек.' });
    if (!openai) return res.status(503).json({ error: 'AI API әлі бапталмаған. Сервердегі OPENAI_API_KEY айнымалысын орнат.' });
    await pool.query(
      "INSERT INTO chat_messages(user_id,role,content) VALUES($1,'user',$2)",
      [req.user.id, message]
    );
    const recent = await pool.query(
      "SELECT role,content FROM chat_messages WHERE user_id=$1 ORDER BY id DESC LIMIT 12",
      [req.user.id]
    );
    const history = recent.rows.reverse().map(m => ({ role: m.role, content: m.content }));
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Сен NUR AI атты пайдалы, сыпайы AI көмекшісің. Қолданушының тіліне сай жауап бер. Белгісіз нәрсені ойдан шығарма.' },
        ...history
      ],
      max_tokens: 900
    });
    const answer = completion.choices?.[0]?.message?.content?.trim() || 'Жауап бос келді. Қайта сұрап көр.';
    await pool.query(
      "INSERT INTO chat_messages(user_id,role,content) VALUES($1,'assistant',$2)",
      [req.user.id, answer]
    );
    res.json({ answer });
  } catch (e) {
    if (e.status === 401) return res.status(502).json({ error: 'AI провайдерінің кілті жарамсыз болуы мүмкін.' });
    if (e.status === 429) return res.status(429).json({ error: 'AI сұрауларының шегі немесе баланс лимиті таусылған болуы мүмкін.' });
    next(e);
  }
});

app.get('/api/admin/overview', requireAdmin, async (req, res, next) => {
  try {
    const counts = await pool.query(`
      SELECT (SELECT COUNT(*) FROM users)::int AS users,
             (SELECT COUNT(*) FROM chat_messages)::int AS messages
    `);
    const users = await pool.query('SELECT id,email,display_name,role,created_at FROM users ORDER BY id DESC LIMIT 100');
    res.json({ stats: counts.rows[0], users: users.rows });
  } catch (e) { next(e); }
});

app.post('/api/admin/users/:id/role', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const role = req.body.role;
    if (!Number.isSafeInteger(id) || !['user','admin'].includes(role)) return res.status(400).json({ error: 'Мәлімет дұрыс емес.' });
    if (id === Number(req.user.id) && role !== 'admin') return res.status(400).json({ error: 'Өзіңнің әкімші құқығыңды осы жерден алып тастай алмайсың.' });
    const result = await pool.query('UPDATE users SET role=$1 WHERE id=$2 RETURNING id,email,display_name,role', [role,id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Пайдаланушы табылмады.' });
    res.json({ user: safeUser(result.rows[0]) });
  } catch (e) { next(e); }
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Серверде қате болды. Қайта байқап көр.' });
});

initDb().then(() => {
  app.listen(port, '0.0.0.0', () => console.log(`NUR AI listening on ${port}`));
}).catch(err => {
  console.error('Database initialization failed:', err);
  process.exit(1);
});
